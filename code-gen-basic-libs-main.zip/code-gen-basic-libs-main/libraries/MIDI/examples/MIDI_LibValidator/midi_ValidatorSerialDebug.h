#pragma once

void setupSerialDebug();
