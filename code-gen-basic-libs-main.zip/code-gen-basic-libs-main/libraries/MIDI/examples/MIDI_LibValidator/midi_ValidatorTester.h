#pragma once

void setupTesters();
bool launchTests();
